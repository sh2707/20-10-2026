@echo off
echo Building PDCA Sender for macOS (Mac Mini)...

:: Target Apple Silicon Mac Mini (M1/M2/M3/M4)
dotnet publish -c Release -r osx-arm64 --self-contained true /p:PublishSingleFile=true /p:PublishTrimmed=false -o ./Publish/Mac_ARM64

:: Target Intel Mac Mini
dotnet publish -c Release -r osx-x64 --self-contained true /p:PublishSingleFile=true /p:PublishTrimmed=false -o ./Publish/Mac_X64

echo.
echo Build Completed!
echo Mac ARM64 output: ./Publish/Mac_ARM64/
echo Mac Intel output: ./Publish/Mac_X64/
pause
